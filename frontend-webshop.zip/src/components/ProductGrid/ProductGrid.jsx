// components/ProductGrid/ProductGrid.jsx
import React from 'react';
import { Card, Button, Row, Col, Container, Badge } from 'react-bootstrap';
import { FaStar } from 'react-icons/fa';
import './ProductGrid.css';

export default function ProductGrid({ products = [] }) {
  // Lấy 4 sản phẩm mới nhất
  const newProducts = products.slice(0, 4);

  return (
    <section className="product-grid py-5">
      <Container>
        <h2 className="text-center mb-4">Sản phẩm mới</h2>
        <p className="text-center text-muted mb-5">Khám phá những sản phẩm mới nhất của chúng tôi</p>
        
        <Row>
          {newProducts.map((product) => (
            <Col lg={3} md={6} className="mb-4" key={product.id}>
              <Card className="h-100 product-card">
                <div className="position-relative">
                  <Card.Img 
                    variant="top" 
                    src={product.image} 
                    className="product-image"
                  />
                  <Badge pill bg="primary" className="position-absolute top-0 start-0 m-2">
                    Mới
                  </Badge>
                </div>
                <Card.Body className="text-center">
                  <Card.Title className="mb-3">{product.name}</Card.Title>
                  
                  <div className="d-flex justify-content-center mb-3">
                    <div className="rating">
                      {[...Array(5)].map((_, i) => (
                        <FaStar 
                          key={i} 
                          color={i < product.rating ? '#ffc107' : '#e4e5e9'} 
                          className="me-1"
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div className="price mb-3">
                    {product.price.toLocaleString()} VND
                  </div>
                  
                  <Button 
                    variant="outline-primary" 
                    className="w-100 add-to-cart-btn"
                  >
                    Thêm vào giỏ
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </section>
  );
}